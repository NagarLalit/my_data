<?php
class User_Dto{
	private $user_id;
	private $user_name;
	private $first_name;
	private $last_name;
	private $mobile_number;
	
	public function getUserId() {
		return $this->user_id;
	}
	public function setUserId($user_id) {
		$this->user_id = $user_id;
		return $this;
	}
	public function getUserName() {
		return $this->user_name;
	}
	public function setUserName($user_name) {
		$this->user_name = $user_name;
		return $this;
	}
	public function getFirstName() {
		return $this->first_name;
	}
	public function setFirstName($first_name) {
		$this->first_name = $first_name;
		return $this;
	}
	public function getLastName() {
		return $this->last_name;
	}
	public function setLastName($last_name) {
		$this->last_name = $last_name;
		return $this;
	}
	public function getMobileNumber() {
		return $this->mobile_number;
	}
	public function setMobileNumber($mobile_number) {
		$this->mobile_number = $mobile_number;
		return $this;
	}
}

?>