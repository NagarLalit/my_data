<?php
//namespace coding_pattern\view;
//namespace view;

require "../model/Book.php";
use Library\Book as lib;

/**
 * @author web-team
 * Brief description about class
 */

class Book_Controller{
	function __construct(){
		
	}
	
	/**
	 * @param unknown $userInfo
	 * @return NULL[]
	 */
	function addBook(){
		$book = new lib();
		$book->addBook(12536,"Immortals Of Meluha");
		$book_info = $book->viewBook();
		echo "ISBN Number :".$book_info["ISBN"].PHP_EOL." Book Name ".$book_info["BOOK_NAME"];	
	}
}

function output(){
	echo "Output of view";
}

$book_controller = new Book_Controller();
$book_controller->addBook();
echo "<br/>";
Library\output();
echo "<br/>";
output();
?>