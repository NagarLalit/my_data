<?php

/**
 * @author web-team
 * Brief description about class
 */
class Example{
	function __construct(){
		
	}
	
	/**
	 * @param unknown $userInfo
	 * @return NULL[]
	 */
	function addUser($user_info){
		try{
			/*
			 * open database connection function
			 */
		}
		catch(Exception $ex){
			return array("CODE"=>$ex->getCode(),"MESSAGE"=>$ex->getMessage());
		}
		catch(mysqli_sql_exception $sql_exception){
			return array("CODE"=>$sql_exception->getCode(),"MESSAGE"=>$sql_exception->getMessage());
		}
		finally {
			/*
			 * close database connection function
			 */
		}
	}
}
?>