<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	date_default_timezone_set('Europe/Berlin');
	
	class Database_Operation
	{
		public $_db_conn;
		private $_connection_status;
		//private $databaseName;
		private $_db_selected_status;
		const DB_SERVER = "localhost";
		const DB_USER = "root";
		const DB_PASS = "root";
		const DB_CMS_NAME = "db_cms";
		const DB_OTS_NAME = "db_ots";
		
		protected $error_array = array(
				'200'=>array('200','success'),
				'301'=>array('301','Unable to prepare query'),
				'302'=>array('302','Unable to execute query'),
				'303'=>array('303','Unable to bind parameter'),
				'304'=>array('304','Unable to bind result'),
				'305'=>array('305','Record already exist'),
				'306'=>array('306','Input data error'),
				'307'=>array('307','Database connection error'),
				'404'=> array('404','Not Found'),
				'500'=>array('500','Internal Server Error'),
				'501'=>array('501','Exception thrown')
				
		);
		//private $stmt;
		function __construct()
		{		 
			//return $this->establishConnection();
		}
		
		public function establishConnection()
		{
			$this->_db_conn = mysqli_connect(self::DB_SERVER, self::DB_USER, self::DB_PASS, self::DB_CMS_NAME) or die(mysqli_error($this->_db_conn));
            
			if(is_resource($this->_db_conn)){
               return array("CODE"=>200,"MESSAGE"=>"Connected successfully");
            }
			else{
                throw invalidargumentexception();
				echo 'failed';
            }
		}
		
		public function closeConnection(){
			if(is_resource($this->_db_conn)){
				return mysqli_close($this->_db_conn);
			}
		}
		
		public function checkConnectionStatus(){
			if($this->_connection_status['Code'] == '200'){
				return true;
			}
			else{
				return false;
			}
		}
		
		public function prepareStatement($query){
			$stmt = $this->_db_conn->prepare($query);
			return $stmt;
		}
		public function executeStatement($stmt){
			mysqli_set_charset($this->_db_conn, 'utf8');
			$value = $stmt->execute();
			$this->stmtStoreResult($stmt);
			return $value;
			
		}
		public function stmtNumberOfRows($stmt){
			return $stmt->num_rows;
		}
		public function stmtFetchRows($stmt){
			try{
				$value =  $stmt->fetch();
				return $value;
			}
			catch(Exception $ex){
				echo 'Message : '.$ex->getMessage();
			}
			
		}
		public function stmtStoreResult($stmt){
			$stmt->store_result();
		}
		
		
		public function executeQuery($query){
			try{
				mysqli_set_charset($this->_db_conn,'utf8');
				$res = mysqli_query($this->_db_conn, $query)or die(mysqli_error($this->_db_conn)) ;
			
				return $res;
			}
			catch(Exception $ex)
			{
				echo 'Message : '.$ex->getMessage();
			}
				//$this->closeConnection();
		}
		
		public function numberOfRows()
		{
			return $this->_db_conn->affected_rows;
		}
		
		public function fetchSingleRows($result){
			try{
				
					return mysqli_fetch_assoc($result);
				
			}
			catch(Exception $ex){
				echo 'Message : '.$ex->getMessage();
			}
		}
		
		public function fetchRows($result){
			try{
				while($rows = mysqli_fetch_assoc($result)){
					return $rows;
				}
			}
			catch(Exception $ex){
				echo 'Message : '.$ex->getMessage();
			}
		}
		
		public function fetchMultipleRows($result){
			try{
				$list= array();
				while($rows = mysqli_fetch_assoc($result))
				{
					$list[] = $rows;
				}
				return $list;
			}
			catch(Exception $ex){
				echo 'Message : '.$ex->getMessage();
			}
		}
		
		function real_escape_string($string)
		{
			try{
				mysqli_set_charset($this->_db_conn,'utf8');
				$res = mysqli_real_escape_string($this->_db_conn, $string);
				return $res;
			}
			catch(Exception $ex)
			{
				echo 'Message : '.$ex->getMessage();
			}
		}
	}

//	
	?>


