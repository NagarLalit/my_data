<?php
require_once "class.DatabaseOperation.php";
require_once "UserDto.php";

class User_Dao extends Database_Operation{
	
	function __construct(){
		
	}
	
	
	/**
	 * @param User_Dto $userDtoObj
	 * @return number[]|string[]|NULL[]|number[]|string[]|NULL[]
	 */
	function addUser(User_Dto $user_dto_obj){
		try{
			/*
			 * connect to database function call
			 */
			$is_connected = $this->establishConnection();
			if($is_connected["CODE"] == 200){
				$query = "INSERT INTO user (USER_NAME,FIRST_NAME,LAST_NAME,MOBILE_NUMBER) VALUES (?,?,?,?)";
				
				$stmt = $this->prepareStatement($query);
				
				if($stmt){
					$user_name = $user_dto_obj->getUserName();
					$first_name = $user_dto_obj->getFirstName();
					$last_name = $user_dto_obj->getLastName();
					$mobile_number = $user_dto_obj->getMobileNumber();
					
					$is_parameter_binded = $stmt->bind_param("ssss",$user_name,$first_name,$last_name,$mobile_number);
					
					if($is_parameter_binded){
						$is_executed = $this->executeStatement($stmt);
						$stmt->store_result();
						if( $is_executed&& ($stmt->affected_rows)){
							return array("CODE"=>200,"MESSAGE"=>"User created successfully","USER_ID"=>$stmt->inserted_id);
						}
						else{
							return array("CODE"=>302,"MESSAGE"=>$this->error_array["302"][1]);
						}
					}
					else{
						return array("CODE"=>303,"MESSAGE"=>$this->error_array["303"][1]);
					}
				}
				else{
					return array("CODE"=>301,"MESSAGE"=>$this->error_array["301"][1]);
				}
			}
			else{
				return $is_connected;
			}
		}
		catch (Exception $ex){
			return array("CODE"=>$ex->getCode(),"MESSAGE"=>$ex->getMessage());
		}
		catch (mysqli_sql_exception $sql_exception){
			return array("CODE"=>$sql_exception->getCode(),"MESSAGE"=>$sql_exception->getMessage());
		}
		finally{
			/*
			 * close database function call
			 */
			$this->closeConnection();
		}
	}
	
	public function getUserDetails($user_id){
		try{
			$is_connected = $this->establishConnection();
			if($is_connected["CODE"] == 200){
				$query = "SELECT * FROM user WHERE ID = ?";
				$stmt = $this->prepareStatement($query);
				
				if($stmt){
					$is_parameter_binded = $stmt->bind_param("i",$user_id);
					if($is_parameter_binded){
						$this->executeStatement($stmt);
						$stmt->store_result();
						if( $this->stmtNumberOfRows($stmt)>=1 ){
							$user_name = "";$first_name = "";$last_name = "";$mobile_number = "";
							$is_result_binded = $stmt->bind_result($user_id,$user_name,$first_name,$last_name,$mobile_number);
							
							if($is_result_binded){
								$stmt->fetch();
								
								$user_dto_obj = new User_Dto();
								
								$user_dto_obj->setUserId($user_id);
								$user_dto_obj->setUserName($user_name);
								$user_dto_obj->setFirstName($first_name);
								$user_dto_obj->setLastName($last_name);
								$user_dto_obj->setMobileNumber($mobile_number);
								
								return array("CODE"=>200,"MESSAGE"=>"User details found","DATA"=>$user_dto_obj);
							}
							else{
								return array("CODE"=>304,"MESSAGE"=>$this->error_array["304"][1]);
							}
						}
						else{
							return array("CODE"=>404,"MESSAGE"=>"User not found");
						}
					}
					else{
						return array("CODE"=>303,"MESSAGE"=>$this->error_array["303"][1]);
					}
				}
				else{
					return array("CODE"=>301,"MESSAGE"=>$this->error_array["301"][1]);
				}
			}
			else{
				return $is_connected;
			}
		}
		catch (Exception $ex){
			return array("CODE"=>$ex->getCode(),"MESSAGE"=>$ex->getMessage());
		}
		catch (mysqli_sql_exception $sql_exception){
			return array("CODE"=>$sql_exception->getCode(),"MESSAGE"=>$sql_exception->getMessage());
		}
		finally{
			/*
			 * close database function call
			 */
			$this->closeConnection();
		}
	}
}
?>