<?php
namespace Library;

class Book{
	private $_isbn_number;
	private $_book_name;
	
	function __construct(){
		
	}
	
	public function addBook($isbn_number,$book_name){
		$this->_isbn_number = $isbn_number;
		$this->_book_name = $book_name;
	}
	
	public function viewBook(){
		return array("ISBN"=>$this->_isbn_number,"BOOK_NAME"=>$this->_book_name);
	}
}

function output(){
	echo "Output of model";
}
?>