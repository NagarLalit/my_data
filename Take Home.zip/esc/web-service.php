<?php
/*
require_once('../lib/nusoap/nusoap.php');

$wsdl   = "https://partners.escardio.org/Bruckmeier/esc_services.asmx?wsdl";
$client = new nusoap_client($wsdl, 'wsdl');

// Input params
$username = "username";
$password = "pass";

// In this demo, we use json data , you can use any other data format for same
$json     = '{"EMAIL":"value1","PASSWORD":"value2"}';

//$client->setCredentials($username, $password);
$error = $client->getError();

if ($error)
{
    echo $error; die();
}

$action = "AuthenticateUser"; // webservice method name

$result = array();

if (isset($action))
{
    $result['response'] = $client->call($action, $json);
}

var_dump($result);
echo "<h3>Output : </h3>";
echo $result['response'];
echo "<h2>Request</h2>";
echo "<pre>" . htmlspecialchars($client->request, ENT_QUOTES) . "</pre>";
echo "<h2>Response</h2>";
echo "<pre>" . htmlspecialchars($client->response, ENT_QUOTES) . "</pre>";
*/

$wsdl = 'https://partners.escardio.org/Bruckmeier/esc_services.asmx?wsdl';
$client = new SoapClient(
    $wsdl,
    array(
        'trace' => 1,
        'use' => SOAP_LITERAL,
    )
);
// web service input params
$request_param = array(
    "secretKey" => "ea00b9ed-572a-4baa-bc70-1c1c2ad873d6",
    "username" => "vinod.sutar@media4u.com",
    "password" => "123vinod",
);

//$params = new \SoapVar("<Acquirer><secretKey>ea00b9ed-572a-4baa-bc70-1c1c2ad873d6</secretKey><username>MyUserId</username><password>MyPassword</password></Acquirer>", XSD_ANYXML);
//$result = $client->Echo($params);
//echo $client->__getLastRequest();
try
{
    $responce_param = $client->AuthenticateUser($request_param);
    var_dump($responce_param);
    if(property_exists($responce_param,"AuthenticateUserResult")){
        var_dump($responce_param->AuthenticateUserResult);
    }
    echo "Request:\n" . $client->__getLastRequest() . "<br/>";
    echo "Response Headers:\n" . $client->__getLastRequestHeaders() . "<br/>";
    echo "Response:\n" . $client->__getLastResponse() . "<br/>";
    echo "Response Headers:\n" . $client->__getLastResponseHeaders() . "<br/>";
   //$responce_param =  $client->call("webservice_methode_name", $request_param); // Alternative way to call soap method
} 
catch (Exception $e) 
{ 
    echo "<h2>Exception Error!</h2>"; 
    echo $e->getMessage(); 
    echo $client->__getLastRequest();
}
?>