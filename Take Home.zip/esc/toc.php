<style>
.baseLangTOC,.targetLangTOC
{
	width: inherit;	
 	margin:0;
	padding:0;
 
	vertical-align: top;
 
}

.red-text
{
	color: #ff7575!important;
}

.save-icon
{
	font-size: 22px;
	padding-left: 15px;
	cursor: pointer;
	display: inline-block;
}

.toc-save-icon
{
	font-size: 17px;
	padding-left: 15px;
	cursor: pointer;
	display: inline-block;
}

.targetLangTOC > div >span
 {
	 float: right;
	 font-size: 20px;
	 cursor: pointer;
	 color: #FAEAEB;
	 font-weight: bold;
 
 }
.targetLangTOC > input[type=text]:HOVER,.targetLangTOC > input[type=text]:FOCUS
 {
 	border: 1px solid red; 
 	background: #FFF;
 	color: #454545;
 }
.tocLevel1
{
border:1px solid #BFE0F1;
background-color: #1B5C7D;
color: white;
padding:8px;
min-height:20px;
vertical-align:middle;
text-decoration: none;
width:90%;
}
.tocLevel1 > .chapter-name
{
	margin:0;
	padding:0;
	padding-left: 0px;
} 

.tocLevel2{
border:1px solid #BFE0F1;
background-color: #247BA8;
color: white;
text-align:left !importent; 
padding:8px;
min-height:20px;
text-decoration: none;
width:90%;
}

.tocLevel2 > .chapter-name
{
	margin:0;
	padding:0;
	padding-left: 15px;
}

.tocLevel3{
border:1px solid #BFE0F1;
background-color: #2C99D2;
text-align:left !importent; 
color: white;
padding:8px;
min-height:20px;
text-decoration: none;
width:90%;
}
.tocLevel3 > .chapter-name
{
	margin:0;
	padding:0;
	padding-left: 25px;
}
.tocLevel4{
border:1px solid #BFE0F1;
background-color: #57AEDB;
text-align:left !importent; 
color: white;
padding:8px;
min-height:20px;
text-decoration: none;
width:90%;
}
.tocLevel4 > .chapter-name
{
	margin:0;
	padding:0;
	padding-left: 35px;
}

.tocLevel5{
border:1px solid #BFE0F1;
background-color: #80C2E4;
text-align:left !importent; 
color: white;
padding:8px;
min-height:20px;
text-decoration: none;
width:90%;
 
}
.tocLevel5 > .chapter-name
{
	margin:0;
	padding:0;
	padding-left: 45px;
}

/******************************Defining base  language colors *************/
.baseLangTOC > .tocLevel1 {background: #E46600; width:98%;}
.baseLangTOC > .tocLevel2 {background: #FF8019; width:98%;}
.baseLangTOC > .tocLevel3 {background: #FF9B4B; width:98%;}
.baseLangTOC > .tocLevel4 {background: #FFB87F; width:98%;}
.baseLangTOC > .tocLevel5 {background: #FFC799; width:98%;}
 
 #barname-editing-table tr td div
 {
 	width: 98% !important;
 }

.tocShuffle > .tocLevel1 {width:100%;}
.tocShuffle > .tocLevel2 {width:100%;}
.tocShuffle > .tocLevel3 {width:100%;}
.tocShuffle > .tocLevel4 {width:100%;}
.tocShuffle > .tocLevel5 {width:100%;}

.tocLevel1 > tbody > tr > td { padding:10px;}
.tocLevel2 > tbody > tr > td { padding:10px;}
.tocLevel3 > tbody > tr > td { padding:10px;}
.tocLevel4 > tbody > tr > td { padding:10px;}
.tocLevel5 > tbody > tr > td { padding:10px;}

/**********************************************************************************************************
***********************************************************************************************************
***********************************************************************************************************
***********************************************************************************************************/


/*******************************************************INDEX LIST TRANSLATION ****************************/

.index-list
{
	width:98%;
	margin: 5px;
}
.index-list tr td
{
	padding: 5px 10px;
	border: 1px solid #777;
}
.index-list tr td >input[type=text]
{
	width:85%;
	padding: 10px;
	border: 1px solid #777;
}

.index-list tr td >input[type=text]:FOCUS
{
	border: 1px solid blue;
}
.faint-red-font
{
	color: #ff0080;
}
.chapter-name > .button
{
	background: #ffb56a!important;
	padding: 3px 10px !important;
	color: #000;
}

.faint-green-font{
	color : #a1ea91;
}

.faint-salmon-font{
	color : #e48683;
}

.faint-light-red-font{
	color : #FC5050;
}

.disabled{
	background-color: #b3b3b3;
}
</style>
<div id="load">
<p class="content1" style="text-align:center; font-size:16px">
			Third Universal Definition of Myocardial Infarction*</p>
		<p class="content1" style="text-align:center;">
			Kristian Thygesen, Joseph S. Alpert, Allan S. Jaffe, Maarten L. Simoons, Bernard R. Chaitman and Harvey D. White, the Writing Group on behalf of the Joint <!--<a class="abbreviation" href="abbr_ESC">-->ESC<!--</a>-->/<!--<a class="abbreviation" href="abbr_ACCF">-->ACCF<!--</a>-->/<!--<a class="abbreviation" href="abbr_AHA">-->AHA<!--</a>-->/<!--<a class="abbreviation" href="abbr_WHF">-->WHF<!--</a>--> Task Force for the Universal Definition of Myocardial Infarction</p>
		<br />
		<p class="content1">
			<span class="bold-black">Co-Chairpersons</span></p>
		<p class="content1">
			<span class="bold-black">Professor Kristian Thygesen</span></p>
		<p class="content1">
			Department of Cardiology,</p>
		<p class="content1">
			Aarhus University Hospital,</p>
		<p class="content1">
			Tage-Hansens Gade 2,</p>
		<p class="content1">
			DK-8000 Aarhus C, Denmark</p>
		 
			<span class="bold-black">Tel: </span><span
                class="copyContent">+45 78467614 </span></p>
		 
    <span class="bold-black">Fax: </span>
    <span class="copyContent"> +45 78467619</span></p>
		 
    <span class="bold-black">Email:  </span><span
        class="copyContent">kristhyg@rm.dk</span></p>
		<br />
		<p class="content1">
			<span class="bold-black">Professor Joseph S. Alpert</span></p>
		<p class="content1">
			Department of Medicine, Univ. of Arizona College of Medicine, 1501 N. Campbell Ave., P.O. Box 245037, Tucson AZ</p>
		<p class="content1">
			+1 85-724-5037, USA</p>
		 
    <span class="bold-black">Tel:</span><span
        class="copyContent"> +1 5206262763 </span></p>
		 
    <span class="bold-black">Fax:</span><span
        class="copyContent"> +1 5206260967</span></p>
		 
    <span class="bold-black">Email: </span><span
        class="copyContent">jalpert@email.arizona.edu</span></p>
		<br />
		<p class="content1">
			<span class="bold-black">Professor Harvey D. White</span></p>
		<p class="content1">
			Green Lane Cardiovascular Service,</p>
		<p class="content1">
			Auckland City Hospital,</p>
		<p class="content1">
			Private Bag 92024,</p>
		<p class="content1">
			1030 Auckland, New Zealand</p>
 
			<span class="bold-black">Tel: </span><span class="copyContent">+64 96309992</span> </p>
 
			<span class="bold-black">Fax: </span><span class="copyContent">+64 96309915</span> </p>
 
			<span class="bold-black">Email: </span><span class="copyContent">harveyw@adhb.govt.nz</span></p>
		<br />
		<p class="content1">
			<span class="bold-black">Task Force Members:</span></p>
		<p class="content1">
			<span class="bold">Biomarker Subcommittee</span></p>
		<p class="content1">
			Allan S. Jaffe (USA),</p>
		<p class="content1">
			Hugo A. Katus (Germany),</p>
		<p class="content1">
			Fred S. Apple (USA),</p>
		<p class="content1">
			Bertil Lindahl (Sweden),</p>
		<p class="content1">
			David A. Morrow (USA)</p>
		<br />
		<p class="content1">
			<span class="bold">ECG Subcommittee</span></p>
		<p class="content1">
			Bernard R. Chaitman (USA),</p>
		<p class="content1">
			Peter M. Clemmensen (Denmark),</p>
		<p class="content1">
			Per Johanson (Sweden),</p>
		<p class="content1">
			Hanoch Hod (Israel)</p>
		<br />
		<p class="content1">
			<span class="bold">Classification Subcommittee</span></p>
		<p class="content1">
			Keith A. Fox (UK),</p>
		<p class="content1">
			Dan Atar (Norway),</p>
		<p class="content1">
			L. Kristin Newby (USA),</p>
		<p class="content1">
			Marcello Galvani (Italy),</p>
		<p class="content1">
			Christian W. Hamm (Germany)</p>
		<br />
		<p class="content1">
			<span class="bold">Intervention Subcommittee</span></p>
		<p class="content1">
			Barry F. Uretsky (USA),</p>
		<p class="content1">
			Ph. Gabriel Steg (France),</p>
		<p class="content1">
			William Wijns (Belgium),</p>
		<p class="content1">
			Jean-Pierre Bassand (France),</p>
		<p class="content1">
			Phillippe Menasché (France),</p>
		<p class="content1">
			Jan Ravkilde (Denmark)</p>
		<br />
		<p class="content1">
			<span class="bold">Trials &amp; Registries Subcommittee</span></p>
		<p class="content1">
			E. Magnus Ohman (USA),</p>
		<p class="content1">
			Elliott M. Antman (USA),</p>
		<p class="content1">
			Lars C. Wallentin (Sweden),</p>
		<p class="content1">
			Paul W. Armstrong (Canada),</p>
		<p class="content1">
			Maarten L. Simoons (The Netherlands)</p>
		<br />
		<p class="content1">
			<span class="bold">Imaging Subcommittee</span></p>
		<p class="content1">
			Richard Underwood (UK),</p>
		<p class="content1">
			Jeroen J. Bax (The Netherlands),</p>
		<p class="content1">
			Robert O. Bonow (USA),</p>
		<p class="content1">
			Fausto Pinto (Portugal),</p>
		<p class="content1">
			Raymond J. Gibbons (USA)</p>
		<br />
		<p class="content1">
			<span class="bold">Heart Failure Subcommittee</span></p>
		<p class="content1">
			James L. Januzzi (USA),</p>
		<p class="content1">
			Markku S. Nieminen (Finland),</p>
		<p class="content1">
			Mihai Gheorghiade (USA),</p>
		<p class="content1">
			Gerasimos Filippatos (Greece)</p>
		<br />
		<p class="content1">
			<span class="bold">Epidemiology Subcommittee</span></p>
		<p class="content1">
			Russell V. Luepker (USA),</p>
		<p class="content1">
			Stephen P. Fortmann (USA),</p>
		<p class="content1">
			Wayne D. Rosamond (USA),</p>
		<p class="content1">
			Dan Levy (USA),</p>
		<p class="content1">
			David Wood (UK)</p>
		<br />
		<p class="content1">
			<span class="bold">Global Perspective Subcommittee</span></p>
		<p class="content1">
			Sidney C. Smith (USA),</p>
		<p class="content1">
			Dayi Hu (China),</p>
		<p class="content1">
			José-Luis Lopez-Sendon (Spain),</p>
		<p class="content1">
			Rose Marie Robertson (USA),</p>
		<p class="content1">
			Douglas Weaver (USA),</p>
		<p class="content1">
			Michal Tendera (Poland),</p>
		<p class="content1">
			Alfred A. Bove (USA),</p>
		<p class="content1">
			Alexander N. Parkhomenko (Ukraine),</p>
		<p class="content1">
			Elena J. Vasilieva (Russia),</p>
		<p class="content1">
			Shanti Mendis (Switzerland)</p>
		<br />
		<p class="content1">
			<span class="bold-black">ESC Staff:</span></p>
		<p class="content1">
			Veronica Dean, Catherine Despres, Nathalie Cameron - Sophia Antipolis, France</p>
		<p class="content1">
			Special thanks to João Morais for his valuable contribution.</p>
		<div class="box">
			<p class="reference">
				*Adapted from the Joint <!--<a class="abbreviation" href="abbr_ESC">-->ESC<!--</a>-->/<!--<a class="abbreviation" href="abbr_ACCF">-->ACCF<!--</a>-->/<!--<a class="abbreviation" href="abbr_AHA">-->AHA<!--</a>-->/<!--<a class="abbreviation" href="abbr_WHF">-->WHF<!--</a>--> expert Consensus Document on the Third Universal Definition of Myocardial Infarction (European Heart Journal 2012 - 10.1093/eurheartj/ehs184).</p>
		</div>
		</div>
<script>
var toc = [
{
"numtree":"1.0.0.0",
"id":"1",
"nametree":"Authors and legal information",
"tocnametree":"Authors and legal information",
"htmlpage":"ENAS5082_1.0.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"2.0.0.0",
"id":"2",
"nametree":"Introduction and overview of aetiologies",
"tocnametree":"Introduction and overview of aetiologies",
"htmlpage":"ENAS5082_2.0.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.0.0.0",
"id":"3",
"nametree":"Pericardial syndromes",
"tocnametree":"Pericardial syndromes",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.1.0.0",
"id":"4",
"nametree":"Definition",
"tocnametree":"Definition",
"htmlpage":"ENAS5082_3.1.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.0.0",
"id":"5",
"nametree":"Acute pericarditis",
"tocnametree":"Acute pericarditis",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.1.0",
"id":"6",
"nametree":"Definition and diagnostic criteria",
"tocnametree":"Definition and diagnostic criteria",
"htmlpage":"ENAS5082_3.2.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.2.0",
"id":"7",
"nametree":"Clinical diagnosis",
"tocnametree":"Clinical diagnosis",
"htmlpage":"ENAS5082_3.2.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.3.0",
"id":"8",
"nametree":"Clinical mgmt. and therapy",
"tocnametree":"Clinical mgmt. and therapy",
"htmlpage":"ENAS5082_3.2.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.4.0",
"id":"9",
"nametree":"Proposed triage",
"tocnametree":"Proposed triage",
"htmlpage":"ENAS5082_3.2.4.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.5.0",
"id":"10",
"nametree":"Management of acute pericarditis",
"tocnametree":"Management of acute pericarditis",
"htmlpage":"ENAS5082_3.2.5.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.6.0",
"id":"11",
"nametree":"Anti-inflammatory therapy",
"tocnametree":"Anti-inflammatory therapy",
"htmlpage":"ENAS5082_3.2.6.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.7.0",
"id":"12",
"nametree":"Treatment of acute pericarditis",
"tocnametree":"Treatment of acute pericarditis",
"htmlpage":"ENAS5082_3.2.7.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.2.8.0",
"id":"13",
"nametree":"Prognosis",
"tocnametree":"Prognosis",
"htmlpage":"ENAS5082_3.2.8.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.3.0.0",
"id":"14",
"nametree":"Recurrent pericarditis",
"tocnametree":"Recurrent pericarditis",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.3.1.0",
"id":"15",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_3.3.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.3.2.0",
"id":"16",
"nametree":"Anti-inflammatory therapies",
"tocnametree":"Anti-inflammatory therapies",
"htmlpage":"ENAS5082_3.3.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.3.3.0",
"id":"17",
"nametree":"Tapering of corticosteroids",
"tocnametree":"Tapering of corticosteroids",
"htmlpage":"ENAS5082_3.3.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.3.4.0",
"id":"18",
"nametree":"Immunosuppresant and biological drugs",
"tocnametree":"Immunosuppresant and biological drugs",
"htmlpage":"ENAS5082_3.3.4.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.3.5.0",
"id":"19",
"nametree":"Management of recurrent pericarditis",
"tocnametree":"Management of recurrent pericarditis",
"htmlpage":"ENAS5082_3.3.5.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.4.0.0",
"id":"20",
"nametree":"Therapeutic algorithm for pericarditis",
"tocnametree":"Therapeutic algorithm for pericarditis",
"htmlpage":"ENAS5082_3.4.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.5.0.0",
"id":"21",
"nametree":"Myopericarditis",
"tocnametree":"Myopericarditis",
"htmlpage":"ENAS5082_3.5.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.0.0",
"id":"22",
"nametree":"Pericardial effusion",
"tocnametree":"Pericardial effusion",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.1.0",
"id":"23",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_3.6.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.2.0",
"id":"24",
"nametree":"Pressure/volume curve",
"tocnametree":"Pressure/volume curve",
"htmlpage":"ENAS5082_3.6.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.3.0",
"id":"25",
"nametree":"Echo. assessment of size",
"tocnametree":"Echo. assessment of size",
"htmlpage":"ENAS5082_3.6.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.4.0",
"id":"26",
"nametree":"Diagnosis of pericardial effusion",
"tocnametree":"Diagnosis of pericardial effusion",
"htmlpage":"ENAS5082_3.6.4.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.5.0",
"id":"27",
"nametree":"Triage and mgmt.",
"tocnametree":"Triage and mgmt.",
"htmlpage":"ENAS5082_3.6.5.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.6.0",
"id":"28",
"nametree":"Initial mgmt. of pericardial effusion",
"tocnametree":"Initial mgmt. of pericardial effusion",
"htmlpage":"ENAS5082_3.6.6.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.7.0",
"id":"29",
"nametree":"Therapy",
"tocnametree":"Therapy",
"htmlpage":"ENAS5082_3.6.7.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.6.8.0",
"id":"30",
"nametree":"Prognosis",
"tocnametree":"Prognosis",
"htmlpage":"ENAS5082_3.6.8.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.7.0.0",
"id":"31",
"nametree":"Cardiac tamponade",
"tocnametree":"Cardiac tamponade",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.7.1.0",
"id":"32",
"nametree":"Definition",
"tocnametree":"Definition",
"htmlpage":"ENAS5082_3.7.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.7.2.0",
"id":"33",
"nametree":"Causes of cardiac tamponade",
"tocnametree":"Causes of cardiac tamponade",
"htmlpage":"ENAS5082_3.7.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.7.3.0",
"id":"34",
"nametree":"Treatment",
"tocnametree":"Treatment",
"htmlpage":"ENAS5082_3.7.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.8.0.0",
"id":"35",
"nametree":"Constrictive pericarditis",
"tocnametree":"Constrictive pericarditis",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.8.1.0",
"id":"36",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_3.8.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.8.2.0",
"id":"37",
"nametree":"Const. pericarditis vs. restrictive CM",
"tocnametree":"Const. pericarditis vs. restrictive cardiomyopathy",
"htmlpage":"ENAS5082_3.8.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.8.3.0",
"id":"38",
"nametree":"Diagnosis",
"tocnametree":"Diagnosis",
"htmlpage":"ENAS5082_3.8.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.8.4.0",
"id":"39",
"nametree":"Therapy overview",
"tocnametree":"Therapy overview",
"htmlpage":"ENAS5082_3.8.4.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.8.5.0",
"id":"40",
"nametree":"Main const. pericardial synd.: def. and therapy",
"tocnametree":"Main const. pericardial synd.: def. and therapy",
"htmlpage":"ENAS5082_3.8.5.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"3.8.6.0",
"id":"41",
"nametree":"Recommendations for therapy",
"tocnametree":"Recommendations for therapy",
"htmlpage":"ENAS5082_3.8.6.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.0.0.0",
"id":"42",
"nametree":"Imaging and diagnostic work-up",
"tocnametree":"Imaging and diagnostic work-up",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.1.0.0",
"id":"43",
"nametree":"Multimodality imaging",
"tocnametree":"Multimodality imaging",
"htmlpage":"ENAS5082_4.1.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.2.0.0",
"id":"44",
"nametree":"General diagnostic work-up",
"tocnametree":"General diagnostic work-up",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.2.1.0",
"id":"45",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_4.2.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.2.2.0",
"id":"46",
"nametree":"High risk patients: clinical predictors",
"tocnametree":"High risk patients: clinical predictors",
"htmlpage":"ENAS5082_4.2.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.2.3.0",
"id":"47",
"nametree":"General diag. work-up",
"tocnametree":"General diag. work-up",
"htmlpage":"ENAS5082_4.2.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.2.4.0",
"id":"48",
"nametree":"First level and second level investigations",
"tocnametree":"First level and second level investigations",
"htmlpage":"ENAS5082_4.2.4.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.2.5.0",
"id":"49",
"nametree":"Main analyses on pericardial fluid",
"tocnametree":"Main analyses on pericardial fluid",
"htmlpage":"ENAS5082_4.2.5.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"4.2.6.0",
"id":"50",
"nametree":"High risk Pts.: diagnostic flowchart",
"tocnametree":"High risk PTS.: suggested diagonstic flowchart",
"htmlpage":"ENAS5082_4.2.6.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.0.0.0",
"id":"51",
"nametree":"Specific aetiologies",
"tocnametree":"Specific aetiologies",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.1.0.0",
"id":"52",
"nametree":"Viral pericarditis",
"tocnametree":"Viral pericarditis",
"htmlpage":"ENAS5082_5.1.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.0.0",
"id":"53",
"nametree":"Bacterial pericarditis",
"tocnametree":"Bacterial pericarditis",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.1.0",
"id":"54",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_5.2.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.2.0",
"id":"55",
"nametree":"Tuberculous pericarditis",
"tocnametree":"Tuberculous pericarditis",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.2.1",
"id":"56",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_5.2.2.1",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.2.2",
"id":"57",
"nametree":"Protocol for evaluation",
"tocnametree":"Protocol for evaluation",
"htmlpage":"ENAS5082_5.2.2.2",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.2.3",
"id":"58",
"nametree":"Management",
"tocnametree":"Management",
"htmlpage":"ENAS5082_5.2.2.3",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.3.0",
"id":"59",
"nametree":"Purulent pericarditis",
"tocnametree":"Purulent pericarditis",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.3.1",
"id":"60",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_5.2.3.1",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.3.2",
"id":"61",
"nametree":"Diagnosis",
"tocnametree":"Diagnosis",
"htmlpage":"ENAS5082_5.2.3.2",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.2.3.3",
"id":"62",
"nametree":"Therapy",
"tocnametree":"Therapy",
"htmlpage":"ENAS5082_5.2.3.3",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.3.0.0",
"id":"63",
"nametree":"Pericarditis in renal failure",
"tocnametree":"Pericarditis in renal failure",
"htmlpage":"ENAS5082_5.3.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.4.0.0",
"id":"64",
"nametree":"Syst. autoimmune and autoinflamm. diseases",
"tocnametree":"Syst. autoimmune and autoinflamm. diseases",
"htmlpage":"ENAS5082_5.4.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.5.0.0",
"id":"65",
"nametree":"Post-cardiac injury syndromes",
"tocnametree":"Post-cardiac injury syndromes",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.5.1.0",
"id":"66",
"nametree":"Definition and diagnosis",
"tocnametree":"Definition and diagnosis",
"htmlpage":"ENAS5082_5.5.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.5.2.0",
"id":"67",
"nametree":"Diagnosis, mgmt. and treatment",
"tocnametree":"Diagnosis, mgmt. and treatment",
"htmlpage":"ENAS5082_5.5.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.6.0.0",
"id":"68",
"nametree":"Traumatic pe and haemopericardium",
"tocnametree":"Traumatic pericard. effusion and haemopericard.",
"htmlpage":"ENAS5082_5.6.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.7.0.0",
"id":"69",
"nametree":"Pericardial involvement in neoplastic disease",
"tocnametree":"Pericardial involvement in neoplastic disease",
"htmlpage":"ENAS5082_5.7.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.8.0.0",
"id":"70",
"nametree":"Other forms of pericardial disease",
"tocnametree":"Other forms of pericardial disease",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.8.1.0",
"id":"71",
"nametree":"Radiation pericarditis",
"tocnametree":"Radiation pericarditis",
"htmlpage":"ENAS5082_5.8.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.8.2.0",
"id":"72",
"nametree":"Chylopericardium",
"tocnametree":"Chylopericardium",
"htmlpage":"ENAS5082_5.8.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.8.3.0",
"id":"73",
"nametree":"Drug-related pericarditis and pericardial effusion",
"tocnametree":"Drug-related pericarditis and pericardial effusion",
"htmlpage":"ENAS5082_5.8.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.8.4.0",
"id":"74",
"nametree":"Effusion in metab. & endocrine disorders",
"tocnametree":"Pericard. effusion in metab. and endocrine disorders",
"htmlpage":"ENAS5082_5.8.4.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.8.5.0",
"id":"75",
"nametree":"Pericardial involvement in PAH",
"tocnametree":"Pericardial involvement in PAH",
"htmlpage":"ENAS5082_5.8.5.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"5.8.6.0",
"id":"76",
"nametree":"Pericardial cysts",
"tocnametree":"Pericardial cysts",
"htmlpage":"ENAS5082_5.8.6.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.0.0.0",
"id":"77",
"nametree":"Age and gender issues in pericardial diseases",
"tocnametree":"Age and gender issues in pericardial diseases",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.1.0.0",
"id":"78",
"nametree":"Paediatric setting",
"tocnametree":"Paediatric setting",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.1.1.0",
"id":"79",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_6.1.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.1.2.0",
"id":"80",
"nametree":"Regimens in children",
"tocnametree":"Regimens in children",
"htmlpage":"ENAS5082_6.1.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.1.3.0",
"id":"81",
"nametree":"Therapy",
"tocnametree":"Therapy",
"htmlpage":"ENAS5082_6.1.3.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.2.0.0",
"id":"82",
"nametree":"Pregnancy, lact. and reproductive issues",
"tocnametree":"Pregnancy, lact. and reproductive issues",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.2.1.0",
"id":"83",
"nametree":"Overview",
"tocnametree":"Overview",
"htmlpage":"ENAS5082_6.2.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.2.2.0",
"id":"84",
"nametree":"Treatment scheme during pregnancy",
"tocnametree":"Treatment scheme during pregnancy",
"htmlpage":"ENAS5082_6.2.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"6.3.0.0",
"id":"85",
"nametree":"The elderly",
"tocnametree":"The elderly",
"htmlpage":"ENAS5082_6.3.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"7.0.0.0",
"id":"86",
"nametree":"Interventional pericardiology and surgery",
"tocnametree":"Interventional pericardiology and surgery",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"7.1.0.0",
"id":"87",
"nametree":"Pericardiocentesis and pericardial drainage",
"tocnametree":"Pericardiocentesis and pericardial drainage",
"htmlpage":"ENAS5082_7.1.0.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"7.2.0.0",
"id":"88",
"nametree":"Surgery for pericardial diseases",
"tocnametree":"Surgery for pericardial diseases",
"htmlpage":"null",
"haspdf":false,
"emailContent":false
},
{
"numtree":"7.2.1.0",
"id":"89",
"nametree":"Pericardial window",
"tocnametree":"Pericardial window",
"htmlpage":"ENAS5082_7.2.1.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"7.2.2.0",
"id":"90",
"nametree":"Pericardiectomy",
"tocnametree":"Pericardiectomy",
"htmlpage":"ENAS5082_7.2.2.0",
"haspdf":false,
"emailContent":false
},
{
"numtree":"8.0.0.0",
"id":"91",
"nametree":"Abbreviations and acronyms",
"tocnametree":"Abbreviations and acronyms",
"htmlpage":"ENAS5082_8.0.0.0",
"haspdf":false,
"emailContent":false
}
];

var abbreviations = [
  {
    "abbr": "ACCF",
    "description": "American College of Cardiology Foundation"
  },
  {
    "abbr": "AHA",
    "description": "American Heart Association"
  },
  {
    "abbr": "CAD",
    "description": "Coronary artery disease"
  },
  {
    "abbr": "CABG",
    "description": "Coronary artery bypass grafting"
  },
  {
    "abbr": "CKMB",
    "description": "Creatine kinase MB isoform"
  },
  {
    "abbr": "cTn",
    "description": "Cardiac  troponin"
  },
  {
    "abbr": "ECG",
    "description": "Electrocardiogram"
  },
  {
    "abbr": "ESC",
    "description": "European Society of Cardiology"
  },
  {
    "abbr": "HF",
    "description": "Heart failure"
  },
  {
    "abbr": "LBBB",
    "description": "Left bundle branch block"
  },
  {
    "abbr": "LVH",
    "description": "Left ventricular hypertrophy"
  },
  {
    "abbr": "ML",
    "description": "Myocardial infarction"
  },
  {
    "abbr": "mV",
    "description": "Millivolt(s)"
  },
  {
    "abbr": "PCI",
    "description": "Percutaneous coronary intervention"
  },
  {
    "abbr": "ST-T",
    "description": "ST-segment-T wave"
  },
  {
    "abbr": "URL",
    "description": "Upper reference limit"
  },
  {
    "abbr": "WHF",
    "description": "World Heart Federation"
  },
  {
    "abbr": "WHO",
    "description": "World Health Organization"
  },
  {
    "abbr": "GISSI-HF",
    "description": "Gruppo Italiano per lo Studio della Sopravvivenza nell'Infarto miocardico"
  },
  {
    "abbr": "BPM",
    "description": "Beats per minute"
  },
  {
    "abbr": "ULN",
    "description": "Upper limit of normal"
  }
];

var gts = [
{
	"page":"ENAS247_1.0.0.0",
	"text":"Third Universal Definition of Myocardial Infarction* Kristian Thygesen, Joseph S. Alpert, Allan S. Jaffe, Maarten L. Simoons, Bernard R. Chaitman and Harvey D. White, the Writing Group on behalf of the Joint ESC/ACCF/AHA/WHF Task Force for the Universal Definition of Myocardial Infarction Co-Chairpersons Professor Kristian Thygesen Department of Cardiology, Aarhus University Hospital, Tage-Hansens Gade 2, DK-8000 Aarhus C, Denmark Tel: +45 78467614 Fax: +45 78467619 Email: kristhyg@rm.dk Professor Joseph S. Alpert Department of Medicine, Univ. of Arizona College of Medicine, 1501 N. Campbell Ave., P.O. Box 245037, Tucson AZ +1 85-724-5037, USA Tel: +1 5206262763 Fax: +1 5206260967 Email: jalpert@email.arizona.edu Professor Harvey D. White Green Lane Cardiovascular Service, Auckland City Hospital, Private Bag 92024, 1030 Auckland, New Zealand Tel: +64 96309992 Fax: +64 96309915 Email: harveyw@adhb.govt.nz Task Force Members: Biomarker Subcommittee Allan S. Jaffe (USA), Hugo A. Katus (Germany), Fred S. Apple (USA), Bertil Lindahl (Sweden), David A. Morrow (USA) ECG Subcommittee Bernard R. Chaitman (USA), Peter M. Clemmensen (Denmark), Per Johanson (Sweden), Hanoch Hod (Israel) Classification Subcommittee Keith A. Fox (UK), Dan Atar (Norway), L. Kristin Newby (USA), Marcello Galvani (Italy), Christian W. Hamm (Germany) Intervention Subcommittee Barry F. Uretsky (USA), Ph. Gabriel Steg (France), William Wijns (Belgium), Jean-Pierre Bassand (France), Phillippe Menasché (France), Jan Ravkilde (Denmark) Trials & Registries Subcommittee E. Magnus Ohman (USA), Elliott M. Antman (USA), Lars C. Wallentin (Sweden), Paul W. Armstrong (Canada), Maarten L. Simoons (The Netherlands) Imaging Subcommittee Richard Underwood (UK), Jeroen J. Bax (The Netherlands), Robert O. Bonow (USA), Fausto Pinto (Portugal), Raymond J. Gibbons (USA) Heart Failure Subcommittee James L. Januzzi (USA), Markku S. Nieminen (Finland), Mihai Gheorghiade (USA), Gerasimos Filippatos (Greece) Epidemiology Subcommittee Russell V. Luepker (USA), Stephen P. Fortmann (USA), Wayne D. Rosamond (USA), Dan Levy (USA), David Wood (UK) Global Perspective Subcommittee Sidney C. Smith (USA), Dayi Hu (China), José-Luis Lopez-Sendon (Spain), Rose Marie Robertson (USA), Douglas Weaver (USA), Michal Tendera (Poland), Alfred A. Bove (USA), Alexander N. Parkhomenko (Ukraine), Elena J. Vasilieva (Russia), Shanti Mendis (Switzerland) ESC Staff: Veronica Dean, Catherine Despres, Nathalie Cameron - Sophia Antipolis, France Special thanks to João Morais for his valuable contribution. *Adapted from the Joint ESC/ACCF/AHA/WHF expert Consensus Document on the Third Universal Definition of Myocardial Infarction (European Heart Journal 2012 - 10.1093/eurheartj/ehs184)."
},
{
	"page":"ENAS247_2.0.0.0",
	"text":"Definition of myocardial infarction Criteria for acute myocardial infarction The term acute myocardial infarction (MI) should be used when there is evidence of myocardial necrosis in a clinical setting consistent with acute myocardial ischaemia. Under these conditions any one of the following criteria meets the diagnosis for MI: Detection of a rise and/or fall of cardiac biomarker values [preferably cardiac troponin (cTn)] with at least one value above the 99th percentile upper reference limit (URL) and with at least one of the following: Symptoms of ischaemia. New or presumed new significant ST-segment–T wave (ST–T) changes or new left bundle branch block (LBBB). Development of pathological Q waves in the ECG. Imaging evidence of new loss of viable myocardium or new regional wall motion abnormality. Identification of an intracoronary thrombus by angiography or autopsy. Cardiac death with symptoms suggestive of myocardial ischaemia and presumed new ischaemic ECG changes, or new LBBB, but death occurred before cardiac biomarkers were obtained, or before cardiac biomarker values would be increased. Percutaneous coronary intervention (PCI) related MI is arbitrarily defined by elevation of cTn values (>5 x 99th percentile URL) in patients with normal baseline values (≤99th percentile URL) or a rise of cTn values >20% if the baseline values are elevated and are stable or falling. In addition, either (i) symptoms suggestive of myocardial ischaemia or (ii) new ischaemic ECG changes or (iii) angiographic findings consistent with a procedural complication or (iv) imaging demonstration of new loss of viable myocardium or new regional wall motion abnormality are required. Stent thrombosis associated with MI when detected by coronary angiography or autopsy in the setting of myocardial ischaemia and with a rise and/or fall of cardiac biomarker values with at least one value above the 99th percentile URL. Coronary artery bypass grafting (CABG) related MI is arbitrarily defined by elevation of cardiac biomarker values (>10 x 99th percentile URL) in patients with normal baseline cTn values (≤99th percentile URL) In addition, either (i) new pathological Q waves or new LBBB, or (ii) angiographic documented new graft or new native coronary artery occlusion, or (iii) imaging evidence of new loss of viable myocardium or new regional wall motion abnormality. Criteria for prior myocardial infarction Any one of the following criteria meets the diagnosis for prior MI: Pathological Q waves with or without symptoms in the absence of non-ischaemic causes. Imaging evidence of a region of loss of viable myocardium that is thinned and fails to contract, in the absence of a non-ischaemic cause. Pathological findings of a prior MI. For interactivity see here"
},
{
	"page":"ENAS247_3.0.0.0",
	"text":"Myocardial infarction is defined as myocardial cell death due to prolonged myocardial ischaemia."
},
{
	"page":"ENAS247_4.1.0.0",
	"text":"Cardiac Biomarkers for detecting myocardial infarction Preferably Detection of rise and/or fall of Troponin (I or T) with at least one value above the 99th percentile of a control group measured with a coefficient of variation ≤10%. When troponin is not available Detection of rise and/or fall of CKMB mass with at least one value above the 99th percentile of a control group measured with a coefficient of variation ≤10%."
},
{
	"page":"ENAS247_4.2.0.0",
	"text":"Elevations of cardiac troponin values because of myocardial injury Injury related to primary myocardial ischaemia (MI type 1). Injury related to supply/demand imbalance of myocardial ischaemia (MI type 2). Injury not related to myocardial ischaemia. Multifactorial or indeterminate myocardial injury. Elevation of cardiac troponins because of myocardial injury Injury related to primary myocardial ischaemia Plaque rupture Intraluminal coronary artery thrombus formation Injury related to supply/demand imbalance of myocardial ischaemia Tachy-/brady-arrhythmias Aortic dissection or severe aortic valve disease Hypertrophic cardiomyopathy Cardiogenic, hypovolaemic, or septic shock Severe respiratory failure Severe anaemia Hypertension with or without LVH Coronary spasm Coronary embolism or vasculitis Coronary endothelial dysfunction without significant CAD Injury not related to myocardial ischaemia Cardiac contusion, surgery, ablation, pacing, or defibrillator shocks Rhabdomyolysis with cardiac involvement Myocarditis Cardiotoxic agents, e.g. anthracyclines, herceptin Multifactorial or indeterminate myocardial injury Heart failure Stress (Takotsubo) cardiomyopathy Severe pulmonary embolism or pulmonary hypertension Sepsis and critically ill patients Renal failure Severe acute neurological diseases, e.g. stroke, subarachnoid haemorrhage Infiltrative diseases, e.g. amyloidosis, sarcoidosis Strenuous exercise"
},
{
	"page":"ENAS247_4.3.0.0",
	"text":"This illustration shows various clinical entities, for example, renal failure, heart failure, tachy- or bradyarrhythmia, cardiac or non-cardiac procedures that can be associated with myocardial injury with cell death marked by cardiac troponin elevation. However, these entities can also be associated with myocardial infarction in case of clinical evidence of acute myocardial ischaemia with rise and/or fall of cardiac troponin."
},
{
	"page":"ENAS247_5.1.0.0",
	"text":"Spontaneous myocardial infarction related to atherosclerotic plaque rupture, ulceration, fissuring, erosion, or dissection with resulting intraluminal thrombus in one or more coronary arteries leading to decreased myocardial blood flow or distal platelet emboli with ensuing myocyte necrosis. The patient may have underlying severe CAD but on occasion non-obstructive or no CAD."
},
{
	"page":"ENAS247_5.2.0.0",
	"text":"In instances of myocardial injury with necrosis where a condition other than CAD contributes to an imbalance between myocardial oxygen supply and/or demand, e.g. coronary endothelial dysfunction, coronary artery spasm, coronary embolism, tachy-brady-arrhythmia, anaemia, respiratory failure, hypotension or hypertension with and without LVH."
},
{
	"page":"ENAS247_5.3.0.0",
	"text":"Differentation between MI Types 1 und 2 according to the Condition of the Coronary Arteries"
},
{
	"page":"ENAS247_5.4.0.0",
	"text":"Cardiac death with symptoms suggestive of myocardial ischaemia and presumed new ischaemic ECG changes or new LBBB, but death occurring before blood samples could be obtained, before cardiac biomarkers could rise, or in rare cases cardiac biomarkers were not collected."
},
{
	"page":"ENAS247_5.5.0.0",
	"text":"Myocardial infarction associated with PCI is arbitrarily defined by elevation of cTn values >5 X 99th percentile URL in patients with normal baseline values (≤99th percentile URL) or a rise of cTn values >20% if the baseline values are elevated and are stable or falling. In addition, either (i) symptoms suggestive of myocardial ischaemia or (ii) new ischaemic ECG changes or new LBBB, or (iii) angiographic findings consistent with a procedural complication or (iv) imaging demonstration of new loss of viable myocardium or new regional wall motion abnormality are required.."
},
{
	"page":"ENAS247_5.6.0.0",
	"text":"Myocardial infarction related to stent-thrombosis is detected by coronary angiography or autopsy in the setting of myocardial ischaemia and with a rise and/or fall of cardiac biomarkers with at least one value >99th percentile URL."
},
{
	"page":"ENAS247_5.7.0.0",
	"text":"Myocardial infarction associated with CABG is arbitrarily defined by elevation of cTn values >10 X 99th percentile URL in patients with normal baseline cTn values (≤99th percentile URL). In addition, either (i) new pathological Q waves or new LBBB, or (ii) angiographic documented new graft or new native coronary artery occlusion, or (iii) imaging evidence of new loss of viable myocardium or new regional wall motion abnormality."
},
{
	"page":"ENAS247_6.1.0.0",
	"text":"ST Segment elevation Criteria New ST elevation at the J point in 2 contiguous leads with the following cut-points: ≥0.1 mV in all leads except leads V2–V3 in men and women. In leads V2–V3, ≥0.2 mV in men ≥40 years and ≥0.25 mV in men <40 years. In leads V2–V3, ≥0.15 mV in women."
},
{
	"page":"ENAS247_6.2.0.0",
	"text":"ST depression and T wave changes New horizontal or down-sloping ST-segment depression ≥0.05 mV in 2 contiguous leads OR T inversion ≥0.1 mV in 2 contiguous leads with prominent R wave or R/S ratio >1"
},
{
	"page":"ENAS247_7.0.0.0",
	"text":"Any Q wave ≥0.02 sec or QS complex in leads V2-V3, or Q wave ≥0.03 sec and ≥0.1 mV deep or QS complex in leads I, II, aVL, aVF or V4–V6 in any 2 leads of a contiguous lead grouping (I, aVL; V1–V6; II, III, aVF), or R wave ≥0.04 sec in V1–V2 and R/S ≥1 with a concordant positive T wave."
},
{
	"page":"ENAS247_8.0.0.0",
	"text":"Common ECG pitfalls in diagnosing myocardial infarction False positives Early repolarization LBBB Pre-excitation J point elevation syndromes, e.g. Brugada syndrome Peri-/​myocarditis Pulmonary embolism Subarachnoid haemorrhage Metabolic disturbances such as hyperkalaemia Cardiomyopathy Lead transposition Cholecystitis Persistent juvenile pattern Malposition of precordial ECG electrodes Tricyclic antidepressants or phenothiazines False negatives Prior MI with Q-waves and/or persistent ST elevation Right ventricular pacing LBBB"
},
{
	"page":"ENAS247_9.0.0.0",
	"text":"Imaging evidence of new loss of viable myocardium or new regional wall motion abnormality in the presence of elevated cardiac troponin values and in the absence of non-ischaemic causes"
},
{
	"page":"ENAS247_10.0.0.0",
	"text":"Reinfarction An AMI that occurs within 28 days of an incident or a recurrent MI is termed reinfarction. Recurrent myocardial infarction An AMI that occurs >28 days after an incident AMI is termed recurrent MI. Silent myocardial infarction Asymptomatic patients who develop new pathologic Q wave criteria for MI or reveal evidence of MI by cardiac imaging, that cannot be directly attributed to a coronary revascularization should be termed silent MI."
},
{
	"page":"ENAS247_11.0.0.0",
	"text":"Tabulation in clinical trials of MI types according to multiples of the 99th percentile upper reference limit of the applied cardiac biomarker Multiples x99% 1-3 3-5 5-10 >10 Total MI type 1 Spontaneous           MI type 2 Secondary           MI type 3a Death           MI type 4a PCI           MI type 4b Stent-thrombus           MI type 4cb Restenosis           MI type 5 CABG           MI = myocardial infarction; PCI = percutaneous coronary intervention; CABG = coronary artery bypass grafting. a Biomarker values are unavailable because of death before blood samples are obtained (blue area). Red areas indicate arbitrarily defined cTn values below the MI decision limit whether PCI or CABG. b Restenosis is defined as ≥50% stenosis at coronary angiography or a complex lesion associated with a rise and or fall of cTn values >99th percentile URL and no other significant obstructive CAD of greater severity following: (i) initially successful stent deployment or (ii) dilatation of a coronary artery stenosis with balloon angioplasty (<50%).  "
},
{
	"page":"ENAS247_12.0.0.0",
	"text":"(N)OAC (Non-vitamin K antagonist) oral anticoagulant °C Degree Celsius 2D/ 2-D Two-dimensional 2hPG 2-h post-load plasma glucose 3D/ 3-D Three-dimensional 5-FU 5-fluorouracil 99mTc-DPD Technetium-99m 3,3-diphosphono-1,2-propanodicarboxylic acid A/C Anticoagulation AAA Abdominal aortic aneurysm AAD Antiarrhythmic drugs AAS Acute aortic syndrome ABC Age, biomarkers, clinical history ABI Ankle-Brachial Index ABPM Ambulatory BP monitoring ACA Aborted cardiac arrest ACC American College of Cardiology ACCA Acute Cardiovascular Care Association ACCF American College of Cardiology Foundation ACCOAST Comparison of Prasugrel at the Time of Percutaneous Coronary Intervention or as Pretreatment at the Time of Diagnosis in Patients with Non-ST Elevation Myocardial Infarction ACE Angiotensin-converting enzyme ACEF Age, creatinine, ejection fraction ACEI/ ACE-I/ ACE-Is Angiotensin converting enzyme inhibitors ACS Acute coronary syndromes ACT Activated clotting time AD Aortic dissection ADA American Diabetes Association/Adenosine deaminase ADD Acute aortic dissection ADP Adenosine diphosphate AEPC Association for European Paediatric and Congenital Cardiology AF Atrial flutter/Atrial fibrillation AFNET German Competence NETwork on Atrial Fibrillation AHA American Heart Association AHF Acute heart failure AHRE Atrial high rate episodes AK Alpha kinase AKI Acute kidney injury AL Amyloid light chain ALAT/ ALT Alanine aminotransferase ALI Acute limb ischaemia AMI Acute myocardial infarction ANA Anti-nuclear antibodies ANCA Anti-neutrophil cytoplasm antibodies AO Aorta AOS Aneurysms-osteoarthritis syndrome AP Accessory pathway APAH Conditions associated with pulmonary arterial hypertension Apo Apolipoprotein apo A I Apolipoprotein A I apo B Apolipoprotein B aPTT Activated partial thromboplastin time AR Aortic regurgitation ARB Angiotensin II receptor blocker/ Angiotensin receptor blocker ARBs Angiotensin receptor blockers ARNI Angiotensin receptor neprilysin inhibition ARVC Arrhythmogenic right ventricular cardiomyopathy AS Aortic stenosis ASA Acetylsalicylic acid ASAT/ AST Aspartate aminotransferase ASCERT American College of Cardiology Foundation–Society of Thoracic Surgeons Database Collaboration ASE American Society of Echocardiography AST/​ALT/​ALP Aspartate / alanine aminotransferase / alkaline phosphatase ASV Adaptive servo-ventilation AT Antithrombin ATOR Atorvastatin ATP Antitachycardiac pacing/​Adenosine triphosphate ATRIA AnTicoagulation and Risk factors In Atrial fibrillation ATS Arterial tortuosity syndrome ATTR Amyloidosis, transthyretin type AUC Area under the curve AV Atrioventricular AVB Atrioventricular block AVID Antiarrhythmic drugs Versus Implantable Defibrillator AVM AV delay management AVP Arginine vasopressin AVR Aortic valve replacement b.i.d. Bis in die (twice daily) b.p.m/ bpm Beats per minute BARI-2D Bypass Angioplasty Revascularization Investigation 2 Diabetes BAS Balloon atrial septostomy BAV Balloon aortic valvuloplasty/Bicuspid aortic valve BB Beta-blocker BBB Bundle branch block BC Blood culture BCNIE Blood culture-negative infective endocarditis BCR-ABL Breakpoint cluster region-Abelson BGA Blood gas analysis BIMA Bilateral internal mammary artery Bi-PAP Bilevel positive airway pressure BiV Biventricular BiVAD Bi-ventricular assist device BMI Body mass index BMPR Bone morphogenetic protein receptor, type 2 BMS Bare metal stent BMT Best medical therapy BNP Brain natriuretic peptide/ B-type natriuretic peptide BP Blood pressure BPA Balloon pulmonary angioplasty BSA Body surface area BUN Blood urea nitrogen CABG Coronary artery bypass graft/ Coronary artery bypass graft surgery CAD Coronary artery disease CAS Carotid artery stenting CASH Cardiac Arrest Study Hamburg Cath/ Lab Catheterization laboratory CCB Calcium channel blocker CCNAP Council on Cardiovascular Nursing and Allied Professions CCP Council for Cardiology Practice CCPC Council on Cardiovascular Primary Care CCS Canadian Cardiovascular Society CCU Coronary care unit CDRIE Cardiac device-related infective endocarditis CEA Carotid endarterectomy/​Carcinoembryonic antigen CFA Common femoral artery CFC Cardiofaciocutaneous CHA2DS2-VASc Congestive heart failure or left ventricular dysfunction, Hypertension, Age ≥75 (doubled), Diabetes, Stroke (doubled)-Vascular disease, Age 65–74, Sex category (female) CHADS2 Cardiac failure, Hypertension, Age, Diabetes, Stroke (doubled) CHARM-Added Candesartan in Heart Failure: Assessment of Reduction in Mortality and Morbidity-Added CHD Coronary heart disease/ Congenital heart disease CHF Congestive heart failure/ Chronic heart failure CI Cardiac index / Contraindication / Confidence interval CIA Common iliac artery CI-AKI Contrast-induced acute kidney injury CIDS Canadian Implantable Defibrillator Study CIED Cardiac implantable electronic device CIN Contrast-induced nephropathy CK Creatine phophokinase/Creatinine kinase CKD Chronic kidney disease CKD-EPI Chronic Kidney Disease Epidemiology Collaboration CK-MB Creatine kinase MB isoform CLI Critical limb ischaemia CMP Cardiomyopathy CMR Cardiac magnetic resonance CMV Cytomegalovirus CO Cardiac output CoA Coarctation / Coarctation of the aorta Cons Conservative cont Continued COPD Chronic obstructive pulmonary disease COT Cardiac Oncology Toxicity COURAGE Clinical Outcomes Utilization Revascularization and Aggressive Drug Evaluation COX Cyclo-oxygenase/ Cyclooxygenase CPAP Continuous positive airway pressure CPET Cardiopulmonary exercise testing CPFE Combined pulmonary fibrosis and emphysema CPG Committee for Practice Guidelines CPVT Catecholaminergic polymorphic ventricular tachycardia CR Cardiac rehabilitation CrCI Creatinine clearance CRP C-reactive protein CRT Cardiac resynchronization therapy CRT-D Cardiac resynchronization therapy defibrillator/ Defibrillator with cardiac resynchronization therapy CRT-P Cardiac resynchronization therapy pacemaker CRUSADE Can Rapid risk stratification of Unstable angina patients Suppress ADverse outcomes with Early implementation of the ACC/AHA guidelines CSF Colony-stimulating factor/Cerebrospinal fluid CSM Carotid sinus massage CSS Carotid sinus syncope/syndrome CT Computed tomographic / tomogram/tomography CTA Computed tomography angiography CTD Connective tissue disease CTEPH Chronic thromboembolic pulmonary hypertension cTN Cardiac troponin CTO Chronic total occlusions CTRCD Cancer Therapeutics–Related Cardiac Dysfunction Ctrl Control CUS Compression venous ultrasonography CV Cardiovascular / Cardioversion CVD Cardiovascular disease CW Continuous wave CXR Chest X-ray DALYs Disability adjusted life years DAPT Dual (oral) antiplatelet therapy DBP Diastolic blood pressure DC Direct current DCC Direct-current cardioversion DCM Dilated cardiomyopathy DDI Drug-drug interactions DEFINITE DEFibrillator In Non-Ischemic cardiomyopathy Treatment Evaluation DES Drug-eluting stent DFT Defibrillation threshold DHP Dihydropyridine DI-DO Door-in to door-out time DLCO Carbon monoxide diffusing capacity DM Diabetes mellitus DNA Deoxyribonucleic acid DPAH Drug induced PAH DPG Diastolic pressure gradient DPP Diabetes prevention program DSA Digital subtraction angiography DT Deceleration time DTB Door-to-balloon time DTIs Direct thrombin inhibitors DUS Duplex ultrasonography / Doppler ultrasound DVT Deep vein thrombosis E/A Ratio of mitral peak velocity of early filling (E) to mitral peak velocity of late filling (A) E/e’ Ratio of early transmitral flow velocity (E) to early mitral annulus velocity (e’) EACPR European Association for Cardiovascular Prevention & Rehabilitation EACTS European Association of Cardio-Thoracic Surgery/ European Association for Cardio-Thoracic Surgery EACVI European Association of Cardiovascular Imaging EANM European Association of Nuclear Medicine EAPCI European Association of Percutaneous Cardiovascular Interventions EAS European Atherosclerosis Society EASD European Association for the Study of Diabetes EBV Epstein-Barr virus ECG Electrocardiogram / Electrocardiographic ECHO Echocardiography/​Echocardiogram ECLS Extracorporeal life support ECST European Carotid Surgery Trial ECVF Extacellular volume fraction ED Erectile dysfunction/ Emergency department EDS-IV Ehlers-Danlos syndrome type IV EF Ejection fraction eGFR Estimated glomerular filtration rate EHRA European Heart Rhythm Association EIA External iliac artery EIF Eukaryotic translation initiation factor EMA European Medicines Agency EMB Endomyocardial biopsy EMS Emergency medical system/service ENA Anti-extractable nuclear antigens Enox Enoxaparin EP Electrophysiology EPD Embolic protection device EPS Electrophysiologic study ER Extended release formulations ERA Endothelin receptor antagonist EROA Effective regurgitant orifice area ERS European Respiratory Society ESC European Society of Cardiology ESCMID European Society of Clinical Microbiology and Infectious Diseases ESH European Society of Hypertension ESO European Stroke Organisation ESR European Society of Radiology/Erythrocyte sedimentation rate ESRD End-stage renal disease ETT Endotracheal tube EU European Union EULAR European League Against Rheumatism EVAR Endovascular aortic repair/reconstruction Exp+ Experimental therapy FAME-2 Fractional Flow Reserve-Guided Percutaneous Coronary Intervention Plus Optimal Medical Treatment Versus Optimal Medical Treatment Alone in Patients With Stable Coronary Artery Disease FBN1 Fibrillin 1 FC Functional class FCH Familial combined hyperlipidaemia FCM Ferric carboxymaltose FDA US Food and Drug Administration/ Food and Drug Administration FDG Fluorodeoxyglucose FFP Fresh frozen plasma FFR Fractional flow reserve FH Familial hypercholesterolaemia FHL1 Four and a half LIM domains 1 FINDRISC FINnish Diabetes RIsk SCore FL False lumen FLUVA Fluvastatin FMC First medical contact FMCTB First-medical-contact-to-balloon time FMF Familial Mediterranean fever Fonda Fondaparinux FPG Fasting plasma glucose FU Follow-up GFR Glomerular filtration rate GGTP Gamma-glutamyl transpeptidase GLP-1 Glucagon-like peptide-1 GLS Global longitudinal strain GM Granulocyte-macrophage GP Glycoprotein / General practitioner GRACE Global Registry of Acute Coronary Events GUCH Grown-up patients with congenital heart disease HAART Highly active antiretroviral treatment HACEK Haemophilus parainfluenzae, H. aphrophilus, H. paraphrophilus, H. influenzae, Actinobacillus actinomycetemcomitans, Cardiobacterium hominis, Eikenella corrodens, Kingella kingae, and K. denitrificans HAS-BLED Hypertension, Abnormal renal/liver function, Stroke, Bleeding history or predisposition, Labile INR, Elderly (65), Drugs concomitantly/alcohol abuse HbA1c Glycated haemoglobin / Glycated haemoglobin A1c HBPM Home BP monitoring HCM Hypertrophic cardiomyopathy HCV Hepatitis C virus HDAC Histone deacetylase HDL High density lipoprotein HDL-C High density lipoprotein-cholesterol HeFH Heterozygous familial hypercholesterolaemia HER2 Human epidermal growth factor receptor 2 HF Heart failure HFA Heart Failure Association H-FABP Heart-type fatty acid-binding protein HFmrEF Heart failure with mid-range ejection fraction HFpEF/ HF-PEF Heart failure with preserved ejection fraction HFrEF/ HF-REF Heart failure with reduced ejection fraction HHD Hypertensive heart disease HHV Human herpesvirus H-ISDN Hydralazine and isosorbide dinitrate HIT Heparin-induced thrombocytopenia HIV Human immunodeficiency virus HoFH Homozygous familial hypercholesterolaemia HPAH Heritable PAH HR Heart rate HRCT High resolution CT hs-CRP high-sensitivity C-reactive protein HT/ HTN Hypertension HTG Hypertrigiyceridaemia i.v. / IV Intravenous IABP Intraaortic balloon pump IAS Inter-atrial septum ICA Invasive coronary angiography ICD Implantable cardioverter defibrillator/ International Classification of Diseases ICH Intracranial haemorrhage ICU Intensive care unit ID Infectious disease IDF International Diabetes Federation IE Infective endocarditis IFG Impaired fasting glucose IFN Interferon-gamma IGRA Interferon-gamma release assay IGT Impaired glucose tolerance IHD Ischaemic heart disease IL-2 Interleukin 2 ILR Implantable loop recorder IMA Internal mammary artery IMH Intramural haematoma IMT Intima–media thickness INR International normalized ratio IN-TIME Implant-based multiparameter telemonitoring of patients with heart failure IOMC Iso-osmolar contrast medium IPAH Idiopathic pulmonary arterial hypertension IPF Idiopathic pulmonary fibrosis IRA Infarct-related artery ISH Isolated systolic hypertension ISHLT International Society for Heart and Lung Transplantation IU International units IUD Intrauterine device IV UHF Intravenous unfractionated heparin IVC Inferior vena cava IVDA Intravenous drug abusers IVIG Intravenous immunoglobulin IVUS Intravascular ultrasound JSAP Japanese Stable Angina Pectoris km per h Kilometres per hour LA Left atrium/atrial LAA Left atrial appendage LAD Left anterior descending (coronary artery) LAE Left atrial enlargement LAH Left anterior hemiblock LAVI Left atrial volume index LBBB Left bundle branch block LCC Left coronary cusp Lcx Left circumflex LDH Lactate dehydrogenase LDL Low-density lipoprotein LDL-C Low-density lipoprotein-cholesterol LDLR Low density lipoprotein receptor LDS Loeys-Dietz syndrome LEAD Lower-extremity artery disease LEOPARD lentigines, ECG abnormalities, ocular hypertelorism, pulmonary stenosis, abnormal genitalia, retardation of growth, and sensorineural deafness LGE Late gadolinium enhancement LHD left heart disease LLN Lower limit of normality LM Left main LMNA Lamin A/C LMWH Low molecular weight heparin LOCM Low-osmolar contrast medium LoE Level of evidence LOVA Lovastatin Lp Lipoprotein Lp(a) Lipoprotein(a) LQTS Long QT syndrome LTBI Latent tuberculosis infection LV Left ventricle / left ventricular LVAD Left ventricular assist device LVEDD Left ventricular end-diastolic diameter LVEDP Left ventricular end diastolic pressure LVEF Left ventricular ejection fraction LVESD Left ventricular end-systolic diameter LVESV Left ventricular end-systolic volume LVH Left ventricular hypertrophy LVM Left ventricular mass LVMI Left ventricular mass index LVOT Left ventricular outflow tract LVOTG Left ventricular outflow tract gradient LVOTO Left ventricular outflow tract obstruction MACE Major adverse cardiac events MADIT Multicenter Automatic Defibrillator Implantation Trial MASS II The medicine, angioplasty, or surgery study Mbq Millibecquerel MCS Mechanical circulatory support MDCT Multidetector computed tomographic angiography/Multi-detector computed tomography MDRD Modifikation of Diet in Renal Disease Med RX Medial therapy MedPed Make Early Diagnosis to Prevent Early Deaths MELAS mitochondrial encephalomyopathy, lactic acidosis, and stroke-like episodes MERFF Myoclonic epilepsy with ragged red fibres MET Metabolic equivalent MetS Metabolic syndrome MI Myocardial infarction MIC Minimum inhibitory concentration MPI Myocardial perfusion imaging MPR Multiplanar reconstruction MPS Myocardial perfusion scintigraphy / Myocardial perfusion stress MR Magnetic resonance/ Mitral regurgitation/ Mineralocorticoid receptor MRA Mineralocorticoid receptor antagonist / Magnetic resonance angiography MRI Magnetic resonance imaging MR-proANP Mid-regional pro atrial natriuretic peptide/ Mid-regional pro A-type natriuretic peptide MRSA Methicillin-resistant Staphylococcus aureus MS Mitral stenosis MSCT Multislice computed tomography MSSA Methicillin-susceptible Staphylococcus aureus mSv Millisievert MUGA Multigated radionuclide angiography mV millivolt(s) MV abn Mitral valve abnormality MWD Minute walk distance MWT Minute walk test MYBPC3 Myosin-binding protein C MYH7 Myosin, heavy chain 7 MYL3 Essential myosin light chain n.a/ NA not available/ Not available N/A Not applicable N/R Not reported NASCET North American Symptomatic Carotid Endarterectomy Trial NCC Non coronary cusp NCDR National cardiovascular data registry NIHSS National Institutes of Health stroke severity scale NIPPV Non-invasive positive pressure ventilation NIV Non-invasive ventilation NNH Numbers needed to harm NNT Numbers needed to treat/ Number of individuals needed to treat NOAC/ NOAC(s) Novel oral anticoagulant / New oral anticoagulant / Non-vitamin K antagonist direct oral anticoagulant/ Non-vitamin K antagonist oral anticoagulant(S) Non-HDL-C Non-HDL cholesterol NP Natriuretic peptide NPV Negative predictive value NRT Nicotine replacement therapy NSAID Non-steroidal antiinflammatory drug(s) NSAIDs Non-steroidal anti-inflammatory drugs NSQIP National surgical quality improvement program NSTE Non-ST-elevation NSTE-ACS Non-ST-segment elevation acute coronary syndrome/ Non-ST elevation acute coronary syndrome NSTEMI Non-ST-elevation myocardial infarction NSVT Non-sustained ventricular tachycardia NTG Nitroglycerine NT-proBNP N-terminal pro B-type/brain natriuretic peptide NVE Native valve endocarditis NYHA New York Heart Association O2 Oxygen OAC Oral anticoagulation/ anticoagulant OAC Oral anticoagulation OARS Open-ended questions, Affirmation, Reflective listening, Summarising OCT Optical coherence tomography OD Organ damage OGTT Oral glucose tolerance test OHCA Out-of-hospital cardiac arrest OHS Obesity hypoventilation syndrome OMT Optimal medical therapy OR Odds ratio ORBIT Outcomes Registry for Better Informed Treatment of Atrial Fibrillation OSA Obstructive sleep apnoea p.o. Per os PA Postero-anterior/ Pulmonary artery/ Physical activity PAD Peripheral artery disease PAH Pulmonary arterial hypertension / Pulmonary hypertension PaO2 Partial pressure of oxygen PAP Pulmonary artery pressure/ Pulmonary arterial pressure PAR Protease-activated receptor PAU Penetrating aortic ulcer PAWP Pulmonary artery wedge pressure PCA Prostacyclin analogues PCC Prothrombin coagulation complax/ Prothrombin complex concentrates PCH Pulmonary capillary haemangiomatosis PCI Percutaneous coronary intervention PCIS Post-cardiac injury syndromes PCR Polymerase chain reaction PCSK9 Proprotein convertase subtilisin/kexin type 9 PCWP Pulmonary capillary wedge pressure PDE Phosphodiesterase type-5 inhibitors/ Phosphodiesterase PDE5 Phosphodiesterase type 5 PE Pulmonary embolism PEA Pulmonary endarterectomy PEP Primary endpoint PESI Pulmonary embolism severity index PET Positron emission tomography PFT Pulmonary function tests PH Pulmonary hypertension PISA Proximal isovelocity surface area PITA Pitavastatin PM Pacemaker/Pain management PMC Percutaneous mitral commissurotomy PPCM Peripartum cardiomyopathy PPI Proton pump inhibitor PPS Post-pericardiotomy syndrome PRAVA Pravastatin PRIMARY PCI Primary percutaneous coronary intervention PRKAG2 Gamma-2 subunit of the adenosine monophosphate-activated protein kinase PS Pulmonary valve stenosis PTA Percutaneous transluminal angioplasty / Pre-test probability PTT Partial thromboplastin time PUFA/ PUFAs Polyunsaturated fatty acid/ Polyunsaturated fatty acids PVC Premature ventricular contraction/ Premature ventricular complex PVE Prosthetic valve endocarditis PVI Pulmonary vein isolation PVL Paravalvular leak PVOD Pulmonary veno-occlusive disease PVR Pulmonary vascular resistance PVS Programmed ventricular stimulation PWV Pulse wave velocity R Vol Regurgitant volume RA Right atrium/ Rheumatoid arthritis RAA Renin–angiotensin–aldosterone RAAS Renin angiotensin aldosterone system RAP Right atrial pressure RAS Renal artery stenosis / Renin-angiotensin system RBBB Right bundle branch block RCC Right coronary cusp RCT/RCTs Randomized controlled trial RF Risk factor rFVIIa Activated recombinant factor VII RHC Right heart catheterization ROSU Rosuvastatin rPA Right pulmonary artery r-PA Reteplase RR Relative risk RRR Relative risk reduction rtPA Recombinant tissue plasminogen activator RV Right ventricle/ventricular RVEDP Right ventricular end-diastolic pressure RVOT Right ventricular outflow tract RVOTO Right ventricular outlow tract obstruction RVSP Right ventricular systolic pressure S.C. Subcutaneous SA Signal-averaged SAA Septal alcohol ablation SADS Sudden arrhythmic death syndrome SAM Systolic anterior motion SAN Sinoatrial node SaO2 Saturated oxygen SAPT Single antiplatelet therapy SAS Sleep apnea syndrome SB Sinus bradycardia SBP Systolic blood pressure SCAD Stable coronary artery disease SCD Sudden cardiac death SCORE Systematic Coronary Risk Evaluation / Systematic Coronary Risk Estimation SFA Superficial femoral artery SGLT2 Sodium glucose co-transporter 2 SIDS Sudden infant death syndrome SIMVA Simvastatin SIRS Systemic inflammatory response SLE Systemic lupus erythematosus SMART Specific, Measurable, Achievable, Realistic and Timely SND Sinus node disease SPAP Systolic pulmonary artery pressure SPECT Single-photon emission computed tomography sPESI Simplified Pulmonary Embolism Severity Index SpO2 Saturation of peripheral oxygen SQTS Short QT syndrome SR Sinus rhythm SSS Sick sinus syndrome STE-ACS ST-segment elevation acute coronary syndrome STEMI ST-elevation myocardial infarction STS Society of Thoracic Surgeon/ Structured telephone support ST-T ST-segment-T wave SUDI Sudden unexplained death in infancy SUDS Sudden unexplained death syndrome SVG Saphenous vein graft SVR Surgical ventricular reconstruction. SVT Supraventricular tachycardia SWISSI II Swiss Interventional Study on Silent Ischemia Type II SYNTAX SYNergy between percutaneous coronary intervention with TAXus and cardiac surgery T1DM Type 1 diabetes mellitus T2DM Type 2 diabetes mellitus TAA Thoracic aortic aneurysm TAAD Thoracic aortic aneurysms and dissection TAI Traumatic aortic injury TAPSE Tricuspid annulus plane systolic excursion TASC TransAtlantic Inter-Society Consensus TAVI Transcatheter aortic valve implantation/ Transaortic valve implantation TB Tuberculosis TC Total cholesterol T-DM1 Trastuzumab-emtansine TE Thromboembolism / Thrombo-embolic TEE Transesophageal echocardiogram TEVAR Thoracic endovascular aortic repair TG Triglyceride TGA Complete transposition of the great arteries Three DE Three dimensional echocardiography TIA Transient ischaemic attack / Transitory ischaemic attack TIBC Total iron-binding capacity TIME Trial of invasive versus medical therapy in elderly patients with chronic symptomatic coronary-artery disease TIMI Thrombolysis In Myocardial Infarction TKI Tyrosine kinase inhibitor TL True lumen TNF Tumor necrosis factor TNK-tPA Tenecteplase TNNI3 Troponin I, cardiac TNNT2 Troponin T TOE Transoesophageal echocardiography / echocardiogram t-PA Tissue plasminogen activator TPM1 Tropomyosin 1 alpha chain TR Tricuspid regurgitation TRAPS Tumour necrosis factor receptor-associated periodic syndrome TRL Triglyceride-rich lipoproteins TRV Tricuspid regurgitant velocity TS Tricuspid stenosis / Turner syndrome TSAT Transferrin saturation TSH Thyroid stimulating hormone TTE Transthoracic echocardiography TTR Time in therapeutic range / Transthyretin TV Tricuspid valve/ Television TVI Time–velocity integral Tx Tendon xanthomata UA Unstable angina UEAD Upper extremity artery disease UFH Unfractionated heparin UHF Ultrafractionated heparin UK United Kingdom ULN Upper limit of normal US United States USA United States of America V/Q Scan ventilation–perfusion scintigraphy VA Vertebral artery/ Ventricular arrhythmia VEGF Vascular endothelial growth factor VF Ventricular fibrillation VHD Valvular heart disease VKA Vitamin K antagonist VO2 Oxygen consumption VPBs Ventricular premature beats vs Versus VSD Ventricular septal defect VT Ventricular tachycardia VTE Venous thromboembolism VV Interventricular VVI Ventricular inhibited pacing WBC White blood cells WCD Wearable cardioverter defibrillator WHF World Heart Federation WHO World Health Organization WPW Wolff-Parkinson-White WU Wood units"
}
];

var new_toc = JSON.parse(JSON.stringify(toc));
var chaptersList = [];
var hierarchical_toc = [];
chaptersList = toc;
var temp_toc = [];
var firstLevelRegex = new RegExp('^\\d+.0.0.0$');
var secondLevelRegex = new RegExp('^\\d+.((?!0)\\d+).0.0$');
var thirdLevelRegex = new RegExp('^\\d+.((?!0)\\d+).((?!0)\\d+).0$');
var fourthLevelRegex = new RegExp('^\\d+.((?!0)\\d+).((?!0)\\d+).((?!0)\\d+)$');

var firstLevelChapters = toc.filter(function(chapter,index){
  //console.log(chapter.numtree);
  var isFirstLevel = chapter.numtree.match(firstLevelRegex);
  if(isFirstLevel){
    chapter.parentId = null;
    chapter.children = [];
    chapter.level = 1;
  	return chapter;
  }
  else{
  	temp_toc[temp_toc.length] = chapter;
  }
});
console.log(firstLevelChapters);
toc = JSON.parse(JSON.stringify(temp_toc));
temp_toc = [];

var secondLevelChapters = toc.filter(function(chapter,index){
	//console.log(chapter.numtree);
  var isSecondLevel = chapter.numtree.match(secondLevelRegex);
  if(isSecondLevel){
    chapter.parentId = null;
    chapter.children = [];
    chapter.level = 2;
	updateChapterInfo(chapter);
  	return chapter;
  }
  else{
  	temp_toc[temp_toc.length] = chapter;
  }
});
toc = JSON.parse(JSON.stringify(temp_toc));
temp_toc = [];
console.log(secondLevelChapters);

var thirdLevelChapters = toc.filter(function(chapter,index){
	//console.log(chapter.numtree);
  var isThirdLevel = chapter.numtree.match(thirdLevelRegex);
  if(isThirdLevel){
    chapter.parentId = null;
    chapter.children = [];
    chapter.level = 3;
	updateChapterInfo(chapter);
  	return chapter;
  }
  else{
  	temp_toc[temp_toc.length] = chapter;
  }
});
toc = JSON.parse(JSON.stringify(temp_toc));
temp_toc = [];
console.log(thirdLevelChapters);

var fourthLevelChapters = toc.filter(function(chapter,index){
	//console.log(chapter.numtree);
  var isFourthLevel = chapter.numtree.match(fourthLevelRegex);
  if(isFourthLevel){
    chapter.parentId = null;
    chapter.children = [];
    chapter.level = 4;
	updateChapterInfo(chapter);
  	return chapter;
  }
  else{
  	temp_toc[temp_toc.length] = chapter;
  }
});
toc = JSON.parse(JSON.stringify(temp_toc));
temp_toc = [];
console.log(fourthLevelChapters);

if(fourthLevelChapters.length > 0){
	for(var i = 0; i < thirdLevelChapters.length; i++){
	  var reg = new RegExp('^'+thirdLevelChapters[i].numtree.split(".")[0]+'.'+thirdLevelChapters[i].numtree.split(".")[1]+'.'+thirdLevelChapters[i].numtree.split(".")[2]+'.((?!0)\\d+)$');
	  //console.log(reg);
	  if((thirdLevelChapters[i].htmlpage == null || thirdLevelChapters[i].htmlpage == "null")){
		thirdLevelChapters[i].children = fourthLevelChapters.filter(function(chapter,index){
			var isSecondLevel = chapter.numtree.match(reg);
			console.log(reg+" "+chapter.numtree);
			if(isSecondLevel){
			  chapter.parentId = thirdLevelChapters[i].id;
			  return chapter;
			}
		});
	  }
	}
}

if(thirdLevelChapters.length > 0){
	for(var i = 0; i < secondLevelChapters.length; i++){
	  var reg = new RegExp('^'+secondLevelChapters[i].numtree.split(".")[0]+'.'+secondLevelChapters[i].numtree.split(".")[1]+'.((?!0)\\d+).0$');
	  //console.log(reg);
	  if((secondLevelChapters[i].htmlpage == null || secondLevelChapters[i].htmlpage == "null")){
		secondLevelChapters[i].children = thirdLevelChapters.filter(function(chapter,index){
			var isSecondLevel = chapter.numtree.match(reg);
			if(isSecondLevel){
			  chapter.parentId = secondLevelChapters[i].id;
			  return chapter;
			}
		});
	  }
	}	
}

if(secondLevelChapters.length > 0){
	for(var i = 0; i < firstLevelChapters.length; i++){
	  var reg = new RegExp('^'+firstLevelChapters[i].numtree.split(".")[0]+'.((?!0)\\d+).0.0$');
	  //console.log(reg);
	  if((firstLevelChapters[i].htmlpage == null || firstLevelChapters[i].htmlpage == "null")){
		firstLevelChapters[i].children = secondLevelChapters.filter(function(chapter,index){
			var isSecondLevel = chapter.numtree.match(reg);
			if(isSecondLevel){
			  chapter.parentId = firstLevelChapters[i].id;
			  return chapter;
			}
		});
	  }
	}	
}
console.log(toc);
console.log("Final array");
console.log(firstLevelChapters);
document.write("<pre>"+JSON.stringify(firstLevelChapters,null,2));
document.body.innerHTML += buildList(firstLevelChapters,false);
function buildList(data, isSub){
    var html = (isSub)?'<div>':''; // Wrap with div if true
    html += '<ul>';
    for(item in data){
        html += '<li>';
        if( data[item].children.length > 0){ // An array will return 'object'
            if(isSub){
                html += data[item].nametree+" ( "+data[item].numtree+" )";
            } else {
                html += data[item].nametree+" ( "+data[item].numtree+" )"; // Submenu found, but top level list item.
            }
            html += buildList(data[item].children, true); // Submenu found. Calling recursively same method (and wrapping it in a div)
        } else {
            html += data[item].nametree+" ( "+data[item].numtree+" )"; // No submenu
        }
        html += '</li>';
    }
    html += '</ul>';
    html += (isSub)?'</div>':'';
    return html;
}

document.body.innerHTML += buildExpandCollapsableList(firstLevelChapters);
document.body.innerHTML += '<a href="http://google.com">Google</a>';
document.body.innerHTML += '<div id="htmlLoader"><a href="abbr_URL">URL</a><span class="sup">a</span>Patient reporting symptoms typical of HF (see <a href="ref_ENAS5195_4.0.0.0.html">Table 1</a>).<br /><div class="box">For interactivity <a href="interactive_0000595.html">see here</a></div></div>';

var Tree = defclass({
    constructor: function (parent) {
        this.parent   = parent || null; // null for root node
        this.children = {};             // for id based lookup
        this.ids      = [];             // for index based lookup
        this.length   = 0;              // for ease of access
    },
    addNode: function (id) {
        var children = this.children;
        if (children.hasOwnProperty(id)) throw new Error(id + " exists");
        return children[this.ids[this.length++] = id] = new Tree(this);
    },
    getChildById: function (id) {
        var children = this.children;
        if (children.hasOwnProperty(id)) return children[id];
        throw new Error(id + " does not exist");
    },
    getAtIndex: function (index) {
        return this.getChildById(this.ids[index]);
    }
});

function defclass(prototype) {
    var constructor = prototype.constructor;
    constructor.prototype = prototype;
    return constructor;
}

var rootNode    = new Tree;
console.log(rootNode);
var child1      = rootNode.addNode("child1");
var innerChild1 = child1.addNode("innerChild1");
var innerChild2 = child1.addNode("innerChild2");
console.log(rootNode);

function getParentAndSibling(chapterId){
	/*
	var node = "";
	node = chaptersList.find(function(chapter){
		return chapter.id == chapterId;
	});
	return node;
	*/
	var node = getChapterReference(chaptersList,chapterId);
	var parentNode = getChapterReference(chaptersList,node["node"].parentId);
	var previousSibling = null;
	var nextSibling = null;
	
	var nodeIndexInParent = getChapterReference(parentNode["node"].children,node["node"].id)["index"];
	if((nodeIndexInParent - 1) >= 0){
		previousSibling = parentNode["node"].children[nodeIndexInParent - 1];
	}
	
	if((nodeIndexInParent + 1) != parentNode["node"].children.length){
		nextSibling = parentNode["node"].children[nodeIndexInParent + 1];
	}
	
	return {"node":node["node"],"parentNode":parentNode,"previousSibling":previousSibling,"nextSibling":nextSibling};
}

function getChapterReference(chaptersList,chapterId){
	var node = "";
	var chapterIndex = "";
	node = chaptersList.find(function(chapter,index){
		if(chapter.id == chapterId){
			chapterIndex = index;
			return chapter.id == chapterId;
		}
	});
	return {"index":chapterIndex,"node":node};
}

function updateChapterInfo(chapterInfo){
	var node = "";
	node = chaptersList.find(function(chapter,index){
		if(chapter.id == chapterInfo.id){
			chaptersList[index] = chapterInfo;
			return chapter.id == chapterInfo.id;
		}
	});
	return node;
}

var handleAnchorTag = function(containerId){
	this.getAllAnchorTags = function(){
		return document.getElementById(containerId).getElementsByTagName("a");
	}

	this.handleClickEvent = function(){
		allAnchorTags = this.getAllAnchorTags();
		for(var i = 0; i < allAnchorTags.length; i++){
			(function(){
				var temp_i = i;
				allAnchorTags[temp_i].addEventListener("click",function(e){
					var isPreventDefaultEvent = false;
					var hrefContent = allAnchorTags[temp_i].getAttribute("href")
					console.log(hrefContent);
					if(hrefContent.indexOf("abbr_") >= 0){
						isPreventDefaultEvent = true;
						//alert("It's an abbreviation text");
						var abbreviation = hrefContent.split("abbr_")[1];
						alert(findAbbreviation(abbreviations,abbreviation));
					}
					else if(hrefContent.indexOf("interactive_") >= 0){
						isPreventDefaultEvent = true;
						alert("It's a tool link");
					}
					else if(hrefContent.indexOf("ref_") >= 0){
						isPreventDefaultEvent = true;
						alert("It's an internal link");
					}
					else if(hrefContent.length == 0 || hrefContent == ""){
						isPreventDefaultEvent = true;
					}

					if(isPreventDefaultEvent){
						event.preventDefault();
					}
				});
			})();
		}
	}
}

function findAbbreviation(abbreviationsList,abbreviationToFind){
	var result = "";
	result = abbreviationsList.find(function(abbr){
		return abbr.abbr == abbreviationToFind;
	});
	return result.description;
}

function findGTSWord(gtsList,textToFind){
	var result = "";
	result = gtsList.filter(function(obj){
		return obj.text.indexOf(textToFind) >= 0;
	});
	return result;
}
/*
var allAnchorTags = document.getElementById("htmlLoader").getElementsByTagName("a");
console.log(allAnchorTags);
for(var i = 0; i < allAnchorTags.length; i++){
	(function(){
		var temp_i = i;
		allAnchorTags[temp_i].addEventListener("click",function(e){
			event.preventDefault();
			console.log(allAnchorTags[temp_i].getAttribute("href"));
		});
	})();
}
*/
var anchorObj = new handleAnchorTag("htmlLoader");
anchorObj.handleClickEvent();
//handleAnchorTag("htmlLoader").handleClickEvent();

function buildExpandCollapsableList(data){
	var html = '';
	for(item in data){		 
        if( data[item].children.length > 0){ // An array will return 'object'
		    html += '<div id="tocElement-'+data[item].id+'" class="tocLevel'+data[item].level+'" onclick="expandChapter('+data[item].id+')"><p class="chapter-name">'+data[item].numtree+' '+data[item].nametree+'</p><span class="float-right plus-icon">+</span></div>';
			html += '<div id="main_'+data[item].id+'" class="sub-chapter-group" style="display:none;  ">';
            html += buildExpandCollapsableList(data[item].children); // Sub chapter found. Calling recursively same method (and wrapping it in a div)
			html += "</div>";
        } else {
			html += '<div id="tocElement-'+data[item].id+'" class="tocLevel'+data[item].level+'" onclick="loadHTMLFile(\''+data[item].htmlpage+'\')"><p class="chapter-name">'+data[item].numtree+' '+data[item].nametree+'</p><span class="float-right">&#10093; </span></div>';
        }
    }
    return html;
}
/*
var reg = new RegExp('^\\d+.0.0.0$');
var temp_toc = [];
var firstLevelChapters = toc.filter(function(chapter,index){
	//console.log(chapter.numtree);
  var isFirstLevel = chapter.numtree.match(reg);
  if(isFirstLevel){
    chapter.parentId = null;
    chapter.children = [];
    chapter.level = 1;
  	return chapter;
  }
  else{
  	temp_toc[temp_toc.length] = chapter;
  }
});

toc = JSON.parse(JSON.stringify(temp_toc));
console.log("toc length"+toc.length);
console.log("temp toc length"+temp_toc.length);
console.log("First level chapters");
console.log(firstLevelChapters);
for(var i = 0; i < firstLevelChapters.length; i++){
  var firstLevelIndex = firstLevelChapters[i].numtree.split(".")[0];
  var reg = new RegExp('^'+firstLevelIndex+'.((?!0)\\d+).0.0$');
  //console.log(reg);
  toc = JSON.parse(JSON.stringify(temp_toc));
  if((firstLevelChapters[i].htmlpage == null || firstLevelChapters[i].htmlpage == "null")){
  	firstLevelChapters[i].children = toc.filter(function(chapter,index){
        var isSecondLevel = chapter.numtree.match(reg);
        if(isSecondLevel){
          chapter.parentId = firstLevelChapters[i].id;
          chapter.children = [];
          chapter.level = 2;
          temp_toc = removeChapter(temp_toc,"numtree",chapter.numtree);
          return chapter;
        }
    });
  }
}
console.log("First level chapters with children");
console.log(firstLevelChapters);

for(var i = 0; i < firstLevelChapters.length; i++){
	
}
*/



/*
temp_toc = [];
var reg = new RegExp('^\\d+.((?!0)\\d+).0.0$');
var secondLevelChapters = toc.filter(function(chapter){
	//console.log(chapter.numtree);
  var isSecondLevel = chapter.numtree.match(reg);
  if(isSecondLevel){
  	return chapter;
  }
  else{
  	temp_toc[temp_toc.length] = chapter;
  }
});
console.log("Second level chapters");
console.log(secondLevelChapters);
var reg = new RegExp('^\\d+.((?!0)\\d+).((?!0)\\d+).0$');
var firstLevelChapters = toc.filter(function(chapter){
	//console.log(chapter.numtree);
  var isFirstLevel = chapter.numtree.match(reg);
  if(isFirstLevel){
  	return chapter;
  }
});
console.log("Third level chapters");
console.log(firstLevelChapters);
*/
console.log("Final temp toc");
console.log(temp_toc);
console.log("Final toc");
console.log(toc);

function removeChapter(array, key, value){
	var element;
	for(var index = 0; index < array.length; index++){
		element = array[index];
		if(element[key] == value){
			array.splice(index, 1);
			break;
		}
	}
	return array;
}

function expandChapter(chapterId)
{
	var dis = document.getElementById("main_"+chapterId).style.display;
	if(dis == "block"){
		document.getElementById("main_"+chapterId).style.display = "none";
	}
	else{
		document.getElementById("main_"+chapterId).style.display = "block";
	}

	var elem = document.getElementById("tocElement-"+chapterId).querySelector("span.float-right");
	if(dis == 'block'){
		elem.innerHTML = '+';
	}
	else{
		elem.innerHTML = '&ndash;';
	}
}

function loadHTMLFile(page){
	alert("Load HTML file :"+page+" here.");
}
</script>
